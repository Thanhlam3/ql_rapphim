﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class Ves_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: Ves_65131636
        public ActionResult Index()
        {
            // Chỉ lấy vé mà Đơn đặt vé của (DatVe) có TrangThai khác 0
            var ves = db.Ves.Include(v => v.DatVe)
                            .Where(v => v.DatVe.TrangThai == 1);
            return View(ves.ToList());
        }

        // GET: Ves_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ve ve = db.Ves.Find(id);
            if (ve == null)
            {
                return HttpNotFound();
            }
            return View(ve);
        }

        // GET: Ves_65131636/Create
        public ActionResult Create()
        {
            ViewBag.MaDatVe = new SelectList(db.DatVes, "MaDatVe", "MaDatVe");
            ViewBag.MaGhe = new SelectList(db.Ghes, "MaGhe", "ViTri");
            return View();
        }

        // POST: Ves_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaVe,MaDatVe,MaGhe,GiaVe")] Ve ve)
        {
            if (ModelState.IsValid)
            {
                db.Ves.Add(ve);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaDatVe = new SelectList(db.DatVes, "MaDatVe", "MaDatVe", ve.MaDatVe);
            ViewBag.MaGhe = new SelectList(db.Ghes, "MaGhe", "ViTri", ve.MaGhe);
            return View(ve);
        }

        // GET: Ves_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ve ve = db.Ves.Find(id);
            if (ve == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaDatVe = new SelectList(db.DatVes, "MaDatVe", "MaDatVe", ve.MaDatVe);
            ViewBag.MaGhe = new SelectList(db.Ghes, "MaGhe", "ViTri", ve.MaGhe);
            return View(ve);
        }

        // POST: Ves_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaVe,MaDatVe,MaGhe,GiaVe")] Ve ve)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ve).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaDatVe = new SelectList(db.DatVes, "MaDatVe", "MaDatVe", ve.MaDatVe);
            ViewBag.MaGhe = new SelectList(db.Ghes, "MaGhe", "ViTri", ve.MaGhe);
            return View(ve);
        }

        // GET: Ves_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ve ve = db.Ves.Find(id);
            if (ve == null)
            {
                return HttpNotFound();
            }
            return View(ve);
        }

        // POST: Ves_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Ve ve = db.Ves.Find(id);
            db.Ves.Remove(ve);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
