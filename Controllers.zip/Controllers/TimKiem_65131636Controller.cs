﻿using _65131636_QLRP.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Data.Entity;

public class TimKiem_65131636Controller : Controller
{
    // Khởi tạo đối tượng kết nối CSDL (DbContext)
    private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

    // --- ACTION MỚI DÀNH RIÊNG CHO KHÁCH HÀNG ---
    // Action này nhận vào từ khóa (string) và mảng các mã thể loại (int[]) từ checkbox
    public ActionResult TimKiemKhachHang(string tuKhoa, int[] maTLs)
    {
        // 1. Khởi tạo ViewModel để chứa dữ liệu trả về cho View
        var model = new TimKiemViewModel
        {
            TuKhoa = tuKhoa, // Giữ lại từ khóa người dùng đã nhập
            MaTLs = maTLs,   // Giữ lại các thể loại người dùng đã chọn
            TatCaTheLoai = db.TheLoais.ToList(), // Lấy danh sách tất cả thể loại để hiển thị lại checkbox
            KetQuaTimKiem = new List<Phim>()     // Khởi tạo danh sách kết quả rỗng
        };

        // 2. Xây dựng câu truy vấn (Query)
     

        var query = db.Phims.Include("TheLoais").AsQueryable();

        // 3. Kiểm tra và thêm điều kiện lọc theo TỪ KHÓA
        if (!string.IsNullOrEmpty(tuKhoa))
        {
            // Lọc phim có Tên HOẶC Tóm tắt chứa từ khóa
            query = query.Where(p => p.TenPhim.Contains(tuKhoa) || p.TomTat.Contains(tuKhoa));
        }

        // 4. Kiểm tra và thêm điều kiện lọc theo THỂ LOẠI (Nhiều - Nhiều)
        if (maTLs != null && maTLs.Length > 0)
        {
   
            query = query.Where(p => p.TheLoais.Any(tl => maTLs.Contains(tl.MaTL)));
        }

        // 5. Thực thi truy vấn
       
        model.KetQuaTimKiem = query.ToList();

        // 6. Trả về View cùng với dữ liệu (Model)
        return View(model);
    }

    // --- ACTION ADMIN ---
    // GET: TimKiem_65131636
    public ActionResult Index(string tuKhoa, int[] maTLs)
    {
        // 1. Tạo model và nạp dữ liệu ban đầu 
        var model = new TimKiemViewModel
        {
            TuKhoa = tuKhoa,
            MaTLs = maTLs,
            TatCaTheLoai = db.TheLoais.ToList(), // Lấy list thể loại để vẽ checkbox
            KetQuaTimKiem = new List<Phim>()     // Mặc định list phim rỗng
        };

        // 2. Khởi tạo truy vấn 
        var query = db.Phims.AsQueryable();

        // 3. Xử lý lọc theo TỪ KHÓA
        if (!string.IsNullOrEmpty(tuKhoa))
        {
            query = query.Where(p => p.TenPhim.Contains(tuKhoa) || p.TomTat.Contains(tuKhoa));
        }

        // 4. Xử lý lọc theo THỂ LOẠI
        if (maTLs != null && maTLs.Length > 0)
        {
            // Kiểm tra phim có thuộc bất kỳ thể loại nào được chọn không
            query = query.Where(p => p.TheLoais.Any(tl => maTLs.Contains(tl.MaTL)));
        }

        // 5. Logic thực thi 
        // Nếu người dùng CÓ nhập từ khóa hoặc có chọn thể loại -> Thì mới chạy tìm kiếm
        if (!string.IsNullOrEmpty(tuKhoa) || (maTLs != null && maTLs.Length > 0))
        {
            model.KetQuaTimKiem = query.ToList(); // Thực thi SQL tìm kiếm
        }
        else
        {
            // Nếu KHÔNG nhập gì cả -> Hiện danh sách mặc định 
          
            model.KetQuaTimKiem = db.Phims.Take(10).ToList();
        }

        return View(model);
    }
}