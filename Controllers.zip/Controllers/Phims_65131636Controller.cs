﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class Phims_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();
        // --- ACTION MỚI DÀNH RIÊNG CHO KHÁCH HÀNG ---
        // GET: Phims_65131636/ChiTietPhim/5
        public ActionResult ChiTietPhim(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            // Lấy phim kèm theo Thể loại và Suất chiếu
            var phim = db.Phims
                         .Include("TheLoais")
                         .Include("SuatChieux")
                         .FirstOrDefault(p => p.MaPhim == id);

            if (phim == null)
            {
                return HttpNotFound();
            }
            return View(phim);
        }
        // --- Action này dành riêng cho Khách hàng ---
        public ActionResult PhimDangChieu()
        {
            // Lấy tất cả phim, bao gồm cả thông tin Thể loại
            var phims = db.Phims.Include("TheLoais").ToList(); // Đảm bảo bạn đã using System.Data.Entity;

            // Trả về View riêng, ép buộc dùng LayoutUser
            return View("PhimDangChieu", "~/Views/Shared/_LayoutUser.cshtml", phims);
        }
        // GET: Phims_65131636
        public ActionResult Index()
        {
   
           
            var phims = db.Phims.Include("TheLoais").ToList();

    
            foreach (var item in phims)
            {
              
                var danhSachTL = item.TheLoais.Select(t => t.TenTL).ToArray();

                // Nối lại thành chuỗi
                item.TenTheLoai = string.Join(", ", danhSachTL);
            }
            // Kiểm tra đăng nhập (Bắt buộc)
            if (Session["Admin"] == null)
            {
                return RedirectToAction("DangNhap", "TaiKhoan_65131636");
            }

            // Lấy thông tin người đang đăng nhập từ Session
            var taiKhoanDangNhap = Session["Admin"] as _65131636_QLRP.Models.TaiKhoan;

            // Truyền quyền sang View: 1=Admin, 2=NhanVien
            ViewBag.MaQuyenHienTai = taiKhoanDangNhap.MaQuyen;

            return View(phims);
        }

        // GET: Phims_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            //  Phải .Include("TheLoais") để lấy được danh sách thể loại
            Phim phim = db.Phims.Include("TheLoais").FirstOrDefault(p => p.MaPhim == id);

            if (phim == null)
            {
                return HttpNotFound();
            }
            return View(phim);
        }

        // GET: Phims_65131636/Create
        public ActionResult Create()
        {
            // Lấy danh sách thể loại để hiển thị checkbox bên View
            ViewBag.TatCaTheLoai = db.TheLoais.ToList();

            return View();
        }

        // POST: Phims_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        // Thêm tham số: int[] selectedGenres, HttpPostedFileBase Avatar
        public ActionResult Create(Phim phim, int[] selectedGenres, HttpPostedFileBase Avatar)
        {
            
            
            // Bỏ qua lỗi check MaPhim vì đây là khóa chính tự tăng
            if (ModelState["MaPhim"] != null) ModelState["MaPhim"].Errors.Clear();

            if (ModelState.IsValid)
            {
                // 1. XỬ LÝ ẢNH
                if (Avatar != null && Avatar.ContentLength > 0)
                {
                    // Lấy tên file
                    string fileName = System.IO.Path.GetFileName(Avatar.FileName);
                    // Lưu file vào thư mục Images
                    string path = Server.MapPath("~/Images/" + fileName);
                    Avatar.SaveAs(path);

                    // Gán tên file vào thuộc tính của đối tượng Phim
                    phim.AnhPhim = fileName;
                }
                else
                {
                    // Nếu không up ảnh thì gán ảnh mặc định (nếu muốn)
                    phim.AnhPhim = "default.jpg";
                }

                // 2. XỬ LÝ THỂ LOẠI 
                

                if (selectedGenres != null && selectedGenres.Length > 0)
                {
                    foreach (var maTL in selectedGenres)
                    {
                        // Tìm thể loại trong DB theo ID
                        var theLoai = db.TheLoais.Find(maTL);
                        if (theLoai != null)
                        {
                            
                            phim.TheLoais.Add(theLoai);
                        }
                    }
                }

               
                db.Phims.Add(phim);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            
            ViewBag.TatCaTheLoai = db.TheLoais.ToList();
            return View(phim);
        }

        // GET: Phims_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            // Load phim kèm theo danh sách thể loại hiện có (QUAN TRỌNG: Include("TheLoais"))
            Phim phim = db.Phims.Include("TheLoais").FirstOrDefault(p => p.MaPhim == id);

            if (phim == null) return HttpNotFound();

            // 1. Lấy danh sách TẤT CẢ thể loại để vẽ ra checkbox
            ViewBag.TatCaTheLoai = db.TheLoais.ToList();

            // 2. Lấy danh sách ID thể loại ĐÃ CHỌN của phim này để tick sẵn
            ViewBag.TheLoaiDaChon = phim.TheLoais.Select(t => t.MaTL).ToList();

            return View(phim);
        }

        // POST: Phims_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Phim phim, int[] selectedGenres) 
        {
            if (ModelState.IsValid)
            {
                // 1. Lấy đối tượng phim GỐC từ Database ra (kèm theo các thể loại cũ)
                var phimInDb = db.Phims.Include("TheLoais").FirstOrDefault(p => p.MaPhim == phim.MaPhim);

                if (phimInDb != null)
                {
                    // 2. Cập nhật các thông tin cơ bản từ form vào đối tượng Database
                    phimInDb.TenPhim = phim.TenPhim;
                    phimInDb.ThoiLuong = phim.ThoiLuong;
                    phimInDb.DoTuoiYeuCau = phim.DoTuoiYeuCau;
                    phimInDb.TomTat = phim.TomTat;
      

                    // 3. Xử lý Ảnh
                    var imgPhim = Request.Files["Avatar"];
                    if (imgPhim != null && imgPhim.ContentLength > 0)
                    {
                        // Lấy tên file
                        string postedFileName = System.IO.Path.GetFileName(imgPhim.FileName);
                        // Lưu file vào server
                        var path = Server.MapPath("/Images/" + postedFileName);
                        imgPhim.SaveAs(path);

                        // Cập nhật tên ảnh mới vào CSDL
                        phimInDb.AnhPhim = postedFileName;
                    }
  

                    // 4. Xử lý Thể Loại (Xóa cũ -> Thêm mới)
                    // 4.1. Xóa sạch các thể loại cũ của phim này
                    phimInDb.TheLoais.Clear();

                    // 4.2. Nếu có chọn thể loại mới, thêm lại vào
                    if (selectedGenres != null)
                    {
                        foreach (var idTheLoai in selectedGenres)
                        {
                            var theLoai = db.TheLoais.Find(idTheLoai);
                            if (theLoai != null)
                            {
                                phimInDb.TheLoais.Add(theLoai);
                            }
                        }
                    }

                    // 5. Lưu tất cả thay đổi xuống Database
                    db.Entry(phimInDb).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
            }

     
            ViewBag.TatCaTheLoai = db.TheLoais.ToList();
            // Giữ lại các ô checkbox người dùng đã tích (nếu có)
            ViewBag.TheLoaiDaChon = selectedGenres != null ? selectedGenres.ToList() : new List<int>();

            return View(phim);
        }

        // GET: Phims_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            // Load phim kèm theo thể loại để hiển thị ở View
            Phim phim = db.Phims.Include("TheLoais").FirstOrDefault(p => p.MaPhim == id);

            if (phim == null) return HttpNotFound();

            return View(phim);
        }

        // POST: Phims_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            // 1. Tìm phim trong DB
            Phim phim = db.Phims.Include("TheLoais").Include("SuatChieux").FirstOrDefault(p => p.MaPhim == id);

            if (phim != null)
            {
                // --- KIỂM TRA RÀNG BUỘC KHÓA NGOẠI ---
                // Nếu phim này đã có Suất Chiếu, không được xóa (hoặc phải xóa suất chiếu trước)
                if (phim.SuatChieux.Count > 0)
                {
                    ModelState.AddModelError("", "Không thể xóa phim này vì đang có Suất Chiếu liên quan. Hãy xóa các suất chiếu trước!");
                    return View(phim);
                }

                // --- XÓA FILE ẢNH VẬT LÝ ---
               
                if (!string.IsNullOrEmpty(phim.AnhPhim))
                {
                    string path = Server.MapPath("~/Images/" + phim.AnhPhim);
                    if (System.IO.File.Exists(path))
                    {
                        System.IO.File.Delete(path);
                    }
                }

                // --- XÓA KHỎI DATABASE ---
               
                db.Phims.Remove(phim);
                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
