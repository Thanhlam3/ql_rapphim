﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class SuatChieux_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: SuatChieux_65131636
        public ActionResult Index()
        {
            // Phải Include Phim và Phong để lấy tên hiển thị ra grid
            var suatChieux = db.SuatChieux.Include(s => s.Phim).Include(s => s.Phong);
            return View(suatChieux.ToList());
        }

        // GET: SuatChieux_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SuatChieu suatChieu = db.SuatChieux.Find(id);
            if (suatChieu == null)
            {
                return HttpNotFound();
            }
            return View(suatChieu);
        }

        // GET: SuatChieux_65131636/Create
        public ActionResult Create()
        {
            // ViewBag.MaPhim và ViewBag.MaPhong phải trùng tên với DropDownList bên View
            ViewBag.MaPhim = new SelectList(db.Phims, "MaPhim", "TenPhim");
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong");
            return View();
        }

        // POST: SuatChieux_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaSC,MaPhim,MaPhong,NgayChieu,GioChieu,GiaVe")] SuatChieu suatChieu)
        {
            if (ModelState.IsValid)
            {
                db.SuatChieux.Add(suatChieu);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaPhim = new SelectList(db.Phims, "MaPhim", "TenPhim", suatChieu.MaPhim);
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", suatChieu.MaPhong);
            return View(suatChieu);
        }

        // GET: SuatChieux_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SuatChieu suatChieu = db.SuatChieux.Find(id);
            if (suatChieu == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaPhim = new SelectList(db.Phims, "MaPhim", "TenPhim", suatChieu.MaPhim);
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", suatChieu.MaPhong);
            return View(suatChieu);
        }

        // POST: SuatChieux_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaSC,MaPhim,MaPhong,NgayChieu,GioChieu,GiaVe")] SuatChieu suatChieu)
        {
            if (ModelState.IsValid)
            {
                db.Entry(suatChieu).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaPhim = new SelectList(db.Phims, "MaPhim", "TenPhim", suatChieu.MaPhim);
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", suatChieu.MaPhong);
            return View(suatChieu);
        }

        // GET: SuatChieux_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SuatChieu suatChieu = db.SuatChieux.Find(id);
            if (suatChieu == null)
            {
                return HttpNotFound();
            }
            return View(suatChieu);
        }

        // POST: SuatChieux_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            SuatChieu suatChieu = db.SuatChieux.Find(id);

            // Kiểm tra xem đã có ai đặt vé cho suất này chưa
            
            try
            {
                db.SuatChieux.Remove(suatChieu);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                // Nếu lỗi (do ràng buộc khóa ngoại), hiển thị thông báo ra View
                ModelState.AddModelError("", "Không thể xóa suất chiếu này vì đã có vé được đặt/bán. Hãy hủy vé trước.");

                // Load lại thông tin Phim/Phòng để hiển thị lại View Delete (tránh lỗi null)
                db.Entry(suatChieu).Reference(s => s.Phim).Load();
                db.Entry(suatChieu).Reference(s => s.Phong).Load();
                return View(suatChieu);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
