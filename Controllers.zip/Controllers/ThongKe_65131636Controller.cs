﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;
using QLRP_CGV_65131636.Models;
using System.Data.Entity;
using System.Globalization; // Cần thêm thư viện này để xử lý ngày tháng

namespace QLRP_CGV_65131636.Controllers
{
    public class ThongKe_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // SỬA: Nhận tham số là string thay vì DateTime? để tránh lỗi null
        public ActionResult Index(string tuNgay, string denNgay)
        {
            var model = new ThongKeViewModel();
            DateTime? dtTuNgay = null;
            DateTime? dtDenNgay = null;

            // --- XỬ LÝ CHUYỂN ĐỔI CHUỖI SANG NGÀY ---
            if (!string.IsNullOrEmpty(tuNgay))
            {
                
                if (DateTime.TryParseExact(tuNgay, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate))
                {
                    dtTuNgay = tempDate;
                }
            }

            if (!string.IsNullOrEmpty(denNgay))
            {
                if (DateTime.TryParseExact(denNgay, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate))
                {
                    dtDenNgay = tempDate;
                }
            }

            // Gán lại vào Model để hiển thị lại trên View (giữ trạng thái form)
            model.TuNgay = dtTuNgay;
            model.DenNgay = dtDenNgay;

            // Xử lý ngày kết thúc (lấy trọn vẹn ngày cuối cùng)
            DateTime? denNgayKeTiep = dtDenNgay.HasValue ? dtDenNgay.Value.AddDays(1) : (DateTime?)null;

            // --- 1. CHUẨN BỊ TRUY VẤN CƠ BẢN ---
            var queryVe = from v in db.Ves
                          join dv in db.DatVes on v.MaDatVe equals dv.MaDatVe
                          select new { v.GiaVe, dv.NgayDat, dv.MaSC };

            var queryDV = from hd in db.HoaDonDichVus
                          join dv in db.DichVus on hd.MaDV equals dv.MaDV
                          select new { hd.SoLuong, dv.Gia, hd.NgayMua };

            // --- 2. ÁP DỤNG BỘ LỌC NGÀY ---
            if (dtTuNgay.HasValue)
            {
                queryVe = queryVe.Where(x => x.NgayDat >= dtTuNgay.Value);
                queryDV = queryDV.Where(x => x.NgayMua >= dtTuNgay.Value);
            }

            if (dtDenNgay.HasValue)
            {
                queryVe = queryVe.Where(x => x.NgayDat < denNgayKeTiep);
                queryDV = queryDV.Where(x => x.NgayMua < denNgayKeTiep);
            }

            // --- 3. TÍNH TOÁN KẾT QUẢ ---
            var tongTienVe = queryVe.Any() ? queryVe.Sum(x => x.GiaVe) : 0;
            var tongTienDichVu = queryDV.Any() ? queryDV.Sum(x => (decimal?)x.SoLuong * x.Gia) : 0;

            model.DoanhThuDichVu = tongTienDichVu ?? 0;
            model.TongDoanhThu = (decimal)tongTienVe + model.DoanhThuDichVu;
            model.TongSoVeBanRa = queryVe.Count();
            model.SoLuongPhimDangChieu = db.Phims.Count();

            // --- 4. TÍNH TOP 5 PHIM ---
            var topPhimQuery = from q in queryVe
                               join sc in db.SuatChieux on q.MaSC equals sc.MaSC
                               join p in db.Phims on sc.MaPhim equals p.MaPhim
                               group q by new { p.MaPhim, p.TenPhim } into g
                               orderby g.Count() descending
                               select new TopPhimViewModel
                               {
                                   TenPhim = g.Key.TenPhim,
                                   SoVeDaBan = g.Count(),
                                   DoanhThuPhim = g.Sum(x => (decimal)x.GiaVe)
                               };

            model.TopPhims = topPhimQuery.Take(5).ToList();

            return View(model);
        }
    }
}