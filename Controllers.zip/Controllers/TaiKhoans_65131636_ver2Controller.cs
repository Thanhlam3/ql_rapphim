﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class TaiKhoans_65131636_ver2Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: TaiKhoans_65131636_ver2
      
        public ActionResult Index()
        {
            // 1. Kiểm tra đăng nhập
            if (Session["Admin"] == null)
            {
                return RedirectToAction("DangNhap", "TaiKhoan_65131636");
            }

            // 2. Lấy thông tin người dùng
            var taiKhoanDangNhap = Session["Admin"] as _65131636_QLRP.Models.TaiKhoan;

            // ---  CHẶN NHÂN VIÊN ---
            // Nếu không phải là Admin (MaQuyen != 1) thì chuyển hướng ra ngoài
            if (taiKhoanDangNhap.MaQuyen != 1)
            {
                // Chuyển hướng về trang Phim 
                return RedirectToAction("Index", "Phims_65131636");
            }
            // -------------------------------------

            ViewBag.MaQuyenHienTai = taiKhoanDangNhap.MaQuyen;

            // 3. Lấy danh sách (Bây giờ chỉ Admin mới vào được đây nên lấy list bình thường)
            var taiKhoans = db.TaiKhoans
                              .Include(t => t.PhanQuyen)
                            
                              .OrderBy(t => t.MaQuyen)
                              .ToList();

            return View(taiKhoans);
        }

        // GET: TaiKhoans_65131636_ver2/Details/5
        public ActionResult Details(string email)
        {
            if (email == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            TaiKhoan taiKhoan = db.TaiKhoans.Find(email); // Find vẫn hoạt động bình thường
            if (taiKhoan == null) return HttpNotFound();
            return View(taiKhoan);
        }

        // GET: TaiKhoans_65131636_ver2/Create
        public ActionResult Create()
        {
            ViewBag.MaQuyen = new SelectList(db.PhanQuyens, "MaQuyen", "TenQuyen");
            return View();
        }

        // POST: TaiKhoans_65131636_ver2/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Email,MatKhau,MaQuyen")] TaiKhoan taiKhoan)
        {
            if (ModelState.IsValid)
            {
                db.TaiKhoans.Add(taiKhoan);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaQuyen = new SelectList(db.PhanQuyens, "MaQuyen", "TenQuyen", taiKhoan.MaQuyen);
            return View(taiKhoan);
        }

        // GET: TaiKhoans_65131636_ver2/Edit/5
        public ActionResult Edit(string email)
        {
            if (email == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            TaiKhoan taiKhoan = db.TaiKhoans.Find(email);
            if (taiKhoan == null) return HttpNotFound();
            ViewBag.MaQuyen = new SelectList(db.PhanQuyens, "MaQuyen", "TenQuyen", taiKhoan.MaQuyen);
            return View(taiKhoan);
        }

        // POST: TaiKhoans_65131636_ver2/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Email,MatKhau,MaQuyen")] TaiKhoan taiKhoan)
        {
            if (ModelState.IsValid)
            {
                db.Entry(taiKhoan).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaQuyen = new SelectList(db.PhanQuyens, "MaQuyen", "TenQuyen", taiKhoan.MaQuyen);
            return View(taiKhoan);
        }

        // GET: TaiKhoans_65131636_ver2/Delete/5
        public ActionResult Delete(string email)
        {
            if (email == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            TaiKhoan taiKhoan = db.TaiKhoans.Find(email);
            if (taiKhoan == null) return HttpNotFound();
            return View(taiKhoan);
        }

        // POST: TaiKhoans_65131636_ver2/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            TaiKhoan taiKhoan = db.TaiKhoans.Find(id);
            db.TaiKhoans.Remove(taiKhoan);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
