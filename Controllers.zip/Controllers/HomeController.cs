﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;
using System.Data.Entity;

namespace _65131636_QLRP.Controllers
{
    public class HomeController : Controller
    {

        // 1. Khai báo kết nối CSDL
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        public ActionResult Index()
        {
            // 2. Lấy danh sách phim (kèm thể loại)
       
            var phims = db.Phims.Include("TheLoais").ToList();

            return View(phims);
        }


        public ActionResult LichChieu(DateTime? ngay)
        {
            // 1. Xác định ngày khách chọn (Mặc định là hôm nay)
            DateTime ngayChieu = ngay ?? DateTime.Today;

            // 2. Tạo danh sách 7 ngày tới để hiển thị trên thanh menu
            var listNgay = new List<DateTime>();
            for (int i = 0; i < 7; i++)
            {
                listNgay.Add(DateTime.Today.AddDays(i));
            }

            // 3. Lấy tất cả suất chiếu trong ngày đã chọn
            var suatChieus = db.SuatChieux
                .Where(s => s.NgayChieu == ngayChieu)
                .Include(s => s.Phim.TheLoais) 
                .Include(s => s.Phong)
                .ToList();

            // 4. Gom nhóm suất chiếu theo Phim
            var listPhim = suatChieus
                .GroupBy(s => s.Phim)
                .Select(g => new PhimLichChieuItem
                {
                    Phim = g.Key,
                    SuatChieus = g.Select(sc => new SuatChieuInfo
                    {
                        MaSC = sc.MaSC,
                        GioChieu = sc.GioChieu ?? TimeSpan.Zero,
                        // Tính ghế trống: Tổng ghế phòng - Số vé đã bán của suất đó
                        GheTrong = (sc.Phong.SoCho ?? 0) - db.DatVes.Count(dv => dv.MaSC == sc.MaSC)
                    }).OrderBy(x => x.GioChieu).ToList()
                })
                .ToList();

            // 5. Đẩy dữ liệu vào ViewModel
            var model = new LichChieuViewModel
            {
                NgayHienTai = ngayChieu,
                DanhSachNgay = listNgay,
                DanhSachPhim = listPhim
            };

            return View(model);
        }
    }
}