﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class HoaDonDichVus_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: HoaDonDichVus_65131636
        public ActionResult XuatHoaDon(int? id)
        {
            // 1. KIỂM TRA ĐẦU VÀO
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest, "Thiếu Mã Đặt Vé (ID)");
            }

            var model = new HoaDonViewModel();
            model.MaDatVe = id.Value;

            // 2. Gọi Procedure lấy thông tin chung
            var thongTinChung = db.Database.SqlQuery<HoaDonViewModel>(
                "EXEC Sp_ThongTinHoaDon_65131636 @MaDatVe",
                new System.Data.SqlClient.SqlParameter("@MaDatVe", id.Value)
            ).FirstOrDefault();

            if (thongTinChung != null)
            {
                model.HoTenKH = thongTinChung.HoTenKH;
                model.SDT = thongTinChung.SDT;
                model.TenPhim = thongTinChung.TenPhim;
                model.TenPhong = thongTinChung.TenPhong;
                model.NgayChieu = thongTinChung.NgayChieu;
                model.GioChieu = thongTinChung.GioChieu;
                model.NgayDat = thongTinChung.NgayDat;
            }

            // 3. Gọi Procedure lấy danh sách Vé
            model.DanhSachVe = db.Database.SqlQuery<ChiTietVe>(
                "EXEC Sp_LayChiTietVe_65131636 @MaDatVe",
                new System.Data.SqlClient.SqlParameter("@MaDatVe", id.Value)
            ).ToList();

            // 4. Gọi Procedure lấy danh sách Dịch vụ
            model.DanhSachDichVu = db.Database.SqlQuery<ChiTietDichVu>(
                "EXEC Sp_LayChiTietDichVu_65131636 @MaDatVe",
                new System.Data.SqlClient.SqlParameter("@MaDatVe", id.Value)
            ).ToList();

            // --- 5.TÍNH TOÁN GIẢM GIÁ  ---

            // Tính tổng tiền vé gốc
            decimal tongTienVe = 0;
            if (model.DanhSachVe != null)
            {
                tongTienVe = model.DanhSachVe.Sum(v => v.GiaVe );
            }

            // Tính tổng tiền dịch vụ
            decimal tongTienDV = 0;
            if (model.DanhSachDichVu != null)
            {
                tongTienDV = model.DanhSachDichVu.Sum(d => d.ThanhTien);
            }

            // Lấy thông tin khách hàng để tính giảm giá (Dựa trên ngày sinh)
            decimal tiLeGiam = 0;
            decimal soTienGiam = 0;

            // Tìm đơn đặt vé để lấy thông tin khách hàng (Dùng EF cho nhanh)
            var datVeEntity = db.DatVes.Find(id.Value);
            if (datVeEntity != null && datVeEntity.KhachHang != null && datVeEntity.KhachHang.NgaySinh.HasValue)
            {
                // Gọi hàm SQL dbo.TinhGiamGia
                tiLeGiam = db.Database.SqlQuery<decimal>(
                    "SELECT dbo.TinhGiamGia(@p0)", datVeEntity.KhachHang.NgaySinh
                ).SingleOrDefault();
            }

            // Tính số tiền được giảm (Chỉ giảm trên tiền vé)
            soTienGiam = tongTienVe * tiLeGiam;

            // Tính tổng cộng cuối cùng
            decimal tongCong = (tongTienVe - soTienGiam) + tongTienDV;

            // Cập nhật lại Model và ViewBag
            model.TongTien = tongCong; // Ghi đè tổng tiền cũ bằng tổng tiền chính xác
            ViewBag.TiLeGiam = tiLeGiam;
            ViewBag.SoTienGiam = soTienGiam;

            return View(model);
        }
        [HttpGet]
        public ActionResult TimKiemVaXuatHoaDon(string searchInput) // Nhận vào chuỗi (text)
        {
            if (string.IsNullOrEmpty(searchInput))
            {
                TempData["Error"] = "Vui lòng nhập SĐT hoặc Mã đặt vé!";
                return RedirectToAction("Index");
            }

            // -- TRƯỜNG HỢP 1: TÌM THEO SỐ ĐIỆN THOẠI --
            
            var donTheoSDT = db.DatVes
                               .Where(d => d.KhachHang.SDT == searchInput)
                               .OrderByDescending(d => d.NgayDat) // Lấy đơn mới nhất
                               .FirstOrDefault();

            if (donTheoSDT != null)
            {
                return RedirectToAction("XuatHoaDon", new { id = donTheoSDT.MaDatVe });
            }

            // -- TRƯỜNG HỢP 2: TÌM THEO MÃ ĐẶT VÉ (ID) --
           
            int maDatVe;
            if (int.TryParse(searchInput, out maDatVe))
            {
                var donTheoID = db.DatVes.Find(maDatVe);
                if (donTheoID != null)
                {
                    return RedirectToAction("XuatHoaDon", new { id = donTheoID.MaDatVe });
                }
            }

            // Nếu chạy hết cả 2 cách mà không tìm thấy
            TempData["Error"] = "Không tìm thấy dữ liệu phù hợp với thông tin: " + searchInput;
            return RedirectToAction("Index");
        }
        public ActionResult Index()
        {
            // Khởi tạo truy vấn, nạp sẵn thông tin Dịch vụ và Khách hàng
            var hoaDonDichVus = db.HoaDonDichVus.Include(h => h.DichVu)
                                                .Include(h => h.KhachHang)
                                                .Include(h => h.DatVe);
                hoaDonDichVus = hoaDonDichVus.Where(h => h.MaDatVe == null || h.DatVe.TrangThai == 1);
            // Sắp xếp ngày mua mới nhất lên đầu
            hoaDonDichVus = hoaDonDichVus.OrderByDescending(h => h.NgayMua);

            return View(hoaDonDichVus.ToList());
        }

        // GET: HoaDonDichVus_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HoaDonDichVu hoaDonDichVu = db.HoaDonDichVus.Find(id);
            if (hoaDonDichVu == null)
            {
                return HttpNotFound();
            }
            return View(hoaDonDichVu);
        }

        // GET: HoaDonDichVus_65131636/Create
        public ActionResult Create()
        {
            ViewBag.MaDV = new SelectList(db.DichVus, "MaDV", "TenDV");
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen");
            return View();
        }

        // POST: HoaDonDichVus_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaHDDV,MaKH,MaDV,SoLuong,NgayMua")] HoaDonDichVu hoaDonDichVu)
        {
            if (ModelState.IsValid)
            {
                db.HoaDonDichVus.Add(hoaDonDichVu);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaDV = new SelectList(db.DichVus, "MaDV", "TenDV", hoaDonDichVu.MaDV);
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen", hoaDonDichVu.MaKH);
            return View(hoaDonDichVu);
        }

        // GET: HoaDonDichVus_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HoaDonDichVu hoaDonDichVu = db.HoaDonDichVus.Find(id);
            if (hoaDonDichVu == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaDV = new SelectList(db.DichVus, "MaDV", "TenDV", hoaDonDichVu.MaDV);
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen", hoaDonDichVu.MaKH);
            return View(hoaDonDichVu);
        }

        // POST: HoaDonDichVus_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaHDDV,MaKH,MaDV,SoLuong,NgayMua")] HoaDonDichVu hoaDonDichVu)
        {
            if (ModelState.IsValid)
            {
                db.Entry(hoaDonDichVu).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaDV = new SelectList(db.DichVus, "MaDV", "TenDV", hoaDonDichVu.MaDV);
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen", hoaDonDichVu.MaKH);
            return View(hoaDonDichVu);
        }

        // GET: HoaDonDichVus_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HoaDonDichVu hoaDonDichVu = db.HoaDonDichVus.Find(id);
            if (hoaDonDichVu == null)
            {
                return HttpNotFound();
            }
            return View(hoaDonDichVu);
        }

        // POST: HoaDonDichVus_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            HoaDonDichVu hoaDonDichVu = db.HoaDonDichVus.Find(id);
            db.HoaDonDichVus.Remove(hoaDonDichVu);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
