﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class KhachHangs_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: KhachHangs_65131636
        public ActionResult Index()
        {
            var khachHangs = db.KhachHangs.Include(k => k.TaiKhoan);
            return View(khachHangs.ToList());
        }

        // GET: KhachHangs_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            KhachHang khachHang = db.KhachHangs.Find(id);
            if (khachHang == null)
            {
                return HttpNotFound();
            }
            return View(khachHang);
        }

        // GET: KhachHangs_65131636/Create
        public ActionResult Create()
        {
            ViewBag.Email = new SelectList(db.TaiKhoans, "Email", "MatKhau");
            return View();
        }

        // POST: KhachHangs_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaKH,HoTen,NgaySinh,SDT,Email")] KhachHang khachHang)
        {
            if (ModelState.IsValid)
            {
                db.KhachHangs.Add(khachHang);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Email = new SelectList(db.TaiKhoans, "Email", "MatKhau", khachHang.Email);
            return View(khachHang);
        }

        // GET: KhachHangs_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            KhachHang khachHang = db.KhachHangs.Find(id);
            if (khachHang == null)
            {
                return HttpNotFound();
            }
            ViewBag.Email = new SelectList(db.TaiKhoans, "Email", "MatKhau", khachHang.Email);
            return View(khachHang);
        }

        // POST: KhachHangs_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaKH,HoTen,NgaySinh,SDT,Email")] KhachHang khachHang)
        {
            if (ModelState.IsValid)
            {
                db.Entry(khachHang).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Email = new SelectList(db.TaiKhoans, "Email", "MatKhau", khachHang.Email);
            return View(khachHang);
        }

        // GET: KhachHangs_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            KhachHang khachHang = db.KhachHangs.Find(id);
            if (khachHang == null)
            {
                return HttpNotFound();
            }
            return View(khachHang);
        }

        // POST: KhachHangs_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            KhachHang khachHang = db.KhachHangs.Find(id);
            db.KhachHangs.Remove(khachHang);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Info()
        {
            if (Session["MaKH"] == null)
            {
                return RedirectToAction("DangNhap", "TaiKhoan_65131636");
            }

            int maKH = int.Parse(Session["MaKH"].ToString());
            var khachHang = db.KhachHangs.Find(maKH);

            if (khachHang == null) return HttpNotFound();

            return View(khachHang);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Info([Bind(Include = "MaKH,HoTen,SDT,DiaChi,Email")] KhachHang kh)
        {
            if (ModelState.IsValid)
            {
                var khInDb = db.KhachHangs.Find(kh.MaKH);
                if (khInDb != null)
                {
                    // Cập nhật thông tin cá nhân
                    khInDb.HoTen = kh.HoTen;
                    khInDb.SDT = kh.SDT;
                    khInDb.NgaySinh = kh.NgaySinh;

                   

                    db.SaveChanges();

                    // Cập nhật lại Session tên hiển thị
                    Session["HoTen"] = kh.HoTen;
                    ViewBag.ThongBao = "Cập nhật thông tin thành công!";
                }
            }
            return View(kh);
        }

        // ---------------------------------------------------------
        // 2. ACTION ĐỔI MẬT KHẨU 
        // ---------------------------------------------------------
        public ActionResult ChangePassword()
        {
            if (Session["MaKH"] == null)
            {
                return RedirectToAction("DangNhap", "TaiKhoan_65131636");
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(string MatKhauCu, string MatKhauMoi, string XacNhanMatKhau)
        {
            // 1. Lấy mã khách hàng từ Session
            int maKH = int.Parse(Session["MaKH"].ToString());

            // 2. Tìm khách hàng để lấy Email
            var kh = db.KhachHangs.Find(maKH);
            if (kh == null) return HttpNotFound();

            // 3. Dùng Email để tìm trong bảng TaiKhoan
            var taiKhoan = db.TaiKhoans.Find(kh.Email); // Vì Email là Primary Key của TaiKhoan

            if (taiKhoan != null)
            {
                // Kiểm tra mật khẩu cũ (So sánh với bảng TaiKhoan)
                if (taiKhoan.MatKhau != MatKhauCu)
                {
                    ModelState.AddModelError("", "Mật khẩu cũ không chính xác!");
                }
                else if (MatKhauMoi != XacNhanMatKhau)
                {
                    ModelState.AddModelError("", "Xác nhận mật khẩu không khớp!");
                }
                else
                {
                    // Cập nhật mật khẩu mới vào bảng TaiKhoan
                    taiKhoan.MatKhau = MatKhauMoi;
                    db.SaveChanges();
                    ViewBag.ThongBao = "Đổi mật khẩu thành công!";
                }
            }
            else
            {
                ModelState.AddModelError("", "Không tìm thấy tài khoản liên kết!");
            }

            return View();
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
