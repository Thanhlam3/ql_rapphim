﻿using System;
using System.Linq;
using System.Web.Mvc;
using _65131636_QLRP.Models;
using System.Text.RegularExpressions;

namespace _65131636_QLRP.Controllers
{
    public class TaiKhoan_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();
        // POST: Đăng ký
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DangKy(KhachHang kh, string matKhau, string xacNhanMatKhau)
        {
            if (ModelState.IsValid)
            {
                // Kiểm tra cú pháp Email 
                string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
                if (!Regex.IsMatch(kh.Email, emailPattern))
                {
                    ViewBag.Error = "Định dạng email không hợp lệ!";
                    return View(kh);
                }
                if (matKhau != xacNhanMatKhau)
                {
                    ViewBag.Error = "Mật khẩu xác nhận không khớp!";
                    return View(kh);
                }

                // --- GỌI STORED PROCEDURE ---
                // Khai báo tham số Output để nhận kết quả trả về
                var resultParam = new System.Data.SqlClient.SqlParameter
                {
                    ParameterName = "@Result",
                    SqlDbType = System.Data.SqlDbType.NVarChar,
                    Size = 200,
                    Direction = System.Data.ParameterDirection.Output
                };

                // Gọi hàm (Lưu ý: tham số phải đúng thứ tự và kiểu dữ liệu)
                db.Database.ExecuteSqlCommand("EXEC DangKyThanhVien @Email, @MatKhau, @HoTen, @NgaySinh, @SDT, @Result OUT",
                    new System.Data.SqlClient.SqlParameter("@Email", kh.Email),
                    new System.Data.SqlClient.SqlParameter("@MatKhau", matKhau),
                    new System.Data.SqlClient.SqlParameter("@HoTen", kh.HoTen),
                    new System.Data.SqlClient.SqlParameter("@NgaySinh", kh.NgaySinh),
                    new System.Data.SqlClient.SqlParameter("@SDT", kh.SDT),
                    resultParam
                );

                // Lấy kết quả trả về từ SQL
                string ketQua = resultParam.Value.ToString();

                if (ketQua == "Đăng ký thành công!")
                {
                    TempData["Success"] = ketQua;
                    return RedirectToAction("DangNhap");
                }
                else
                {
                    // Nếu lỗi (Email trùng hoặc lỗi hệ thống)
                    ViewBag.Error = ketQua;
                    return View(kh);
                }
            }
            return View(kh);
        }
        // GET: Đăng nhập
        public ActionResult DangNhap()
        {
            return View();
        }

        // POST: Xử lý Đăng nhập
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DangNhap(string email, string matKhau)
        {
            if (ModelState.IsValid)
            {
                // 1. Tìm tài khoản
                var taiKhoan = db.TaiKhoans.FirstOrDefault(t => t.Email == email && t.MatKhau == matKhau);

                if (taiKhoan != null)
                {
                    // --- TRƯỜNG HỢP 1: ADMIN (1) HOẶC NHÂN VIÊN (2) ---
                    if (taiKhoan.MaQuyen == 1 || taiKhoan.MaQuyen == 2)
                    {
                        
                        // Vì không có bảng NhanVien, ta gán tên cố định luôn
                        Session["Admin"] = taiKhoan;
                        Session["HoTen"] = "Quản Trị Viên"; 

                        // Chuyển hướng vào trang Quản lý Phim
                        
                        return RedirectToAction("Index", "Phims_65131636");
                    }

                    // --- TRƯỜNG HỢP 2: KHÁCH HÀNG (3) ---
                    else if (taiKhoan.MaQuyen == 3)
                    {
                        var kh = db.KhachHangs.FirstOrDefault(k => k.Email == email);

                        if (kh != null)
                        {
                            Session["TaiKhoan"] = kh;
                            Session["HoTen"] = kh.HoTen;
                            Session["MaKH"] = kh.MaKH;

                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            // Tài khoản hợp lệ nhưng chưa có thông tin hồ sơ
                            Session["TaiKhoan"] = taiKhoan;
                            Session["HoTen"] = "Khách hàng mới";
                            return RedirectToAction("Index", "Home");
                        }
                    }
                }
                else
                {
                    ViewBag.Error = "Email hoặc mật khẩu không đúng!";
                }
            }
            return View();
        }

        // Đăng xuất
        public ActionResult DangXuat()
        {
            Session.Clear(); // Xóa sạch phiên làm việc
            return RedirectToAction("Index", "Home");
        }

        // Đăng ký 
        public ActionResult DangKy()
        {
            return View();
        }
       
    }
}