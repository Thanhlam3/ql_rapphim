﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class DatVes_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();
        // Action Xử lý Duyệt đơn hàng
        public ActionResult XacNhanDonHang(int id)
        {
            // 1. Tìm đơn vé theo ID
            var donVe = db.DatVes.Find(id);

            if (donVe != null)
            {
                // 2. Cập nhật trạng thái từ 0 (Chờ duyệt) sang 1 (Đã duyệt)
                donVe.TrangThai = 1;

                // 3. Lưu vào Database
                db.SaveChanges();
            }

            // 4. Quay lại trang danh sách chờ duyệt (để duyệt tiếp đơn khác)
            return RedirectToAction("ChoDuyet");
        }
        public ActionResult ChoDuyet()
        {
            // Lọc các vé có trạng thái là chờ duyệt (Ví dụ TrangThai == 0 )
            var danhSachChoDuyet = db.DatVes.Where(x => x.TrangThai == 0).ToList();

            // Trả về View Index nhưng với danh sách đã lọc
            return View(danhSachChoDuyet);
        }
        // GET: DatVes_65131636
        public ActionResult Index()
        {
            // Thêm điều kiện Where để chỉ lấy những đơn có TrangThai = 1 (Đã duyệt/Đã thanh toán)
            var datVes = db.DatVes.Include(d => d.KhachHang)
                                  .Include(d => d.SuatChieu)
                                  .Where(d => d.TrangThai == 1) 
                                  .OrderByDescending(d => d.NgayDat); // Sắp xếp mới nhất lên đầu

            return View(datVes.ToList());
        }

        // GET: DatVes_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatVe datVe = db.DatVes.Find(id);
            if (datVe == null)
            {
                return HttpNotFound();
            }
            return View(datVe);
        }

        // GET: DatVes_65131636/Create
        public ActionResult Create()
        {
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen");
            ViewBag.MaSC = new SelectList(db.SuatChieux, "MaSC", "MaSC");
            return View();
        }

        // POST: DatVes_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaDatVe,MaKH,MaSC,NgayDat")] DatVe datVe)
        {
            if (ModelState.IsValid)
            {
                db.DatVes.Add(datVe);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen", datVe.MaKH);
            ViewBag.MaSC = new SelectList(db.SuatChieux, "MaSC", "MaSC", datVe.MaSC);
            return View(datVe);
        }

        // GET: DatVes_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatVe datVe = db.DatVes.Find(id);
            if (datVe == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen", datVe.MaKH);
            ViewBag.MaSC = new SelectList(db.SuatChieux, "MaSC", "MaSC", datVe.MaSC);
            return View(datVe);
        }

        // POST: DatVes_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaDatVe,MaKH,MaSC,NgayDat")] DatVe datVe)
        {
            if (ModelState.IsValid)
            {
                db.Entry(datVe).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaKH = new SelectList(db.KhachHangs, "MaKH", "HoTen", datVe.MaKH);
            ViewBag.MaSC = new SelectList(db.SuatChieux, "MaSC", "MaSC", datVe.MaSC);
            return View(datVe);
        }

        // GET: DatVes_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DatVe datVe = db.DatVes.Find(id);
            if (datVe == null)
            {
                return HttpNotFound();
            }
            return View(datVe);
        }

        // POST: DatVes_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DatVe datVe = db.DatVes.Find(id);

            if (datVe != null)
            {
                // 1. Xóa các Vé con liên quan đến Đơn đặt vé này trước
                var danhSachVeCon = db.Ves.Where(v => v.MaDatVe == id).ToList();
                if (danhSachVeCon.Count > 0)
                {
                    db.Ves.RemoveRange(danhSachVeCon);
                }

              
                // 2. Sau khi sạch sẽ các bảng con, mới xóa bảng cha (DatVe)
                db.DatVes.Remove(datVe);

                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
