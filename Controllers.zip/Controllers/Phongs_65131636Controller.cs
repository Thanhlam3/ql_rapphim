﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class Phongs_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: Phongs_65131636
        public ActionResult Index()
        {
            return View(db.Phongs.ToList());
        }

        // GET: Phongs_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Phong phong = db.Phongs.Find(id);
            if (phong == null)
            {
                return HttpNotFound();
            }
            return View(phong);
        }

        // GET: Phongs_65131636/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Phongs_65131636/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaPhong,TenPhong,SoCho")] Phong phong)
        {
            if (ModelState.IsValid)
            {
                // LƯU PHÒNG TRƯỚC ĐỂ LẤY ID
                db.Phongs.Add(phong);
                db.SaveChanges();

                // TỰ ĐỘNG SINH GHẾ DỰA TRÊN SỐ CHỖ
                if (phong.SoCho > 0)
                {
                    // Quy định: Mỗi hàng có 10 ghế (A1-A10, B1-B10...)
                 
                    int soGheMotHang = 10;

                    for (int i = 0; i < phong.SoCho; i++)
                    {
                        // Tính toán hàng (0->A, 1->B...) và cột (1, 2, 3...)
                        int rowIndex = i / soGheMotHang;
                        int colIndex = (i % soGheMotHang) + 1;

                        // Chuyển số thành chữ cái (0 = A, 1 = B, 2 = C...)
                        char rowChar = (char)('A' + rowIndex);
                        string tenGhe = rowChar.ToString() + colIndex;

                        // Tạo đối tượng ghế
                        Ghe gheMoi = new Ghe();
                        gheMoi.MaPhong = phong.MaPhong;
                        gheMoi.ViTri = tenGhe;

                        // Thêm vào hàng đợi lưu
                        db.Ghes.Add(gheMoi);
                    }

             
                    db.SaveChanges();
                }

                return RedirectToAction("Index");
            }

            return View(phong);
        }

        // GET: Phongs_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Phong phong = db.Phongs.Find(id);
            if (phong == null)
            {
                return HttpNotFound();
            }
            return View(phong);
        }

        // POST: Phongs_65131636/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaPhong,TenPhong,SoCho")] Phong phong)
        {
            if (ModelState.IsValid)
            {
                db.Entry(phong).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(phong);
        }

        // GET: Phongs_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Phong phong = db.Phongs.Find(id);
            if (phong == null)
            {
                return HttpNotFound();
            }
            return View(phong);
        }

        // POST: Phongs_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Phong phong = db.Phongs.Find(id);

            
            var ghes = db.Ghes.Where(g => g.MaPhong == id).ToList();
            db.Ghes.RemoveRange(ghes);

            db.Phongs.Remove(phong);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}