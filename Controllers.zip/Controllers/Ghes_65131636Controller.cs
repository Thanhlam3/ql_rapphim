﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class Ghes_65131636Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // GET: Ghes_65131636
        public ActionResult Index(int? maPhong)
        {
            // 1. Lấy danh sách phòng để đưa vào Dropdown lọc
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", maPhong);

            // 2. Lấy danh sách ghế
            var ghes = db.Ghes.Include(g => g.Phong);

            // 3. Nếu có chọn phòng (maPhong khác null) thì lọc
            if (maPhong != null)
            {
                ghes = ghes.Where(g => g.MaPhong == maPhong);
            }

            // Sắp xếp: Ưu tiên theo Tên Phòng, sau đó đến Tên Ghế (độ dài tên rồi đến chữ cái để A2 đứng trước A10)
            ghes = ghes.OrderBy(g => g.Phong.TenPhong).ThenBy(g => g.ViTri.Length).ThenBy(g => g.ViTri);

            return View(ghes.ToList());
        }

        // GET: Ghes_65131636/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ghe ghe = db.Ghes.Find(id);
            if (ghe == null)
            {
                return HttpNotFound();
            }
            return View(ghe);
        }

        // GET: Ghes_65131636/Create
        public ActionResult Create()
        {
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong");
            return View();
        }

        // POST: Ghes_65131636/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaGhe,MaPhong,ViTri")] Ghe ghe)
        {
            if (ModelState.IsValid)
            {
                db.Ghes.Add(ghe);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", ghe.MaPhong);
            return View(ghe);
        }

        // GET: Ghes_65131636/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ghe ghe = db.Ghes.Find(id);
            if (ghe == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", ghe.MaPhong);
            return View(ghe);
        }

        // POST: Ghes_65131636/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaGhe,MaPhong,ViTri")] Ghe ghe)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ghe).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaPhong = new SelectList(db.Phongs, "MaPhong", "TenPhong", ghe.MaPhong);
            return View(ghe);
        }

        // GET: Ghes_65131636/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ghe ghe = db.Ghes.Find(id);
            if (ghe == null)
            {
                return HttpNotFound();
            }
            return View(ghe);
        }

        // POST: Ghes_65131636/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Ghe ghe = db.Ghes.Find(id);
            try
            {
                db.Ghes.Remove(ghe);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
               
                ModelState.AddModelError("", "Không thể xóa ghế này vì đã có vé bán ra liên quan đến ghế này.");

                // Load lại thông tin Phòng để hiển thị lại View (tránh lỗi null)
                db.Entry(ghe).Reference(g => g.Phong).Load();
                return View(ghe);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
