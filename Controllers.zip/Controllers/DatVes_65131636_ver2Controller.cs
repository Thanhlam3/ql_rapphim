﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using _65131636_QLRP.Models;

namespace _65131636_QLRP.Controllers
{
    public class DatVes_65131636_ver2Controller : Controller
    {
        private QLRP_CGV_65131636Entities db = new QLRP_CGV_65131636Entities();

        // --- QUẢN LÝ VÉ CỦA TÔI ---
        public ActionResult LichSuDatVe()
        {
            if (Session["TaiKhoan"] == null) return RedirectToAction("DangNhap", "TaiKhoan_65131636");

            int maKH = (int)Session["MaKH"];

            // Lấy danh sách vé của khách hàng này, sắp xếp ngày đặt mới nhất lên đầu
            var listVe = db.DatVes
                           .Where(d => d.MaKH == maKH)
                           .OrderByDescending(d => d.NgayDat)
                           .Include("SuatChieu")
                           .Include("SuatChieu.Phim")
                           .Include("SuatChieu.Phong")
                           .ToList();

            return View(listVe);
        }

        // Chức năng Hủy vé (Xóa) - Chỉ cho hủy khi chưa duyệt
        public ActionResult HuyDatVe(int id)
        {
            var datVe = db.DatVes.Find(id);
            if (datVe != null && datVe.TrangThai == 0) // Chỉ xóa khi chờ duyệt
            {
                // BƯỚC 1: Xóa các Vé con (Ghế ngồi) trước
                var chiTietVes = db.Ves.Where(v => v.MaDatVe == id).ToList();
                if (chiTietVes.Count > 0)
                {
                    db.Ves.RemoveRange(chiTietVes);
                }

                // BƯỚC 2: Xóa các Dịch vụ đi kèm 
                // Tìm các hóa đơn dịch vụ có dính líu đến Mã Đặt Vé này
                var dichVus = db.HoaDonDichVus.Where(hd => hd.MaDatVe == id).ToList();
                if (dichVus.Count > 0)
                {
                    db.HoaDonDichVus.RemoveRange(dichVus);
                }

                // BƯỚC 3: Sau khi dọn sạch con cái, xóa Đơn Vé (Cha)
                db.DatVes.Remove(datVe);

                db.SaveChanges(); 
                TempData["Msg"] = "Đã hủy vé thành công!";
            }
            else
            {
                TempData["Error"] = "Không thể hủy vé này.";
            }

            return RedirectToAction("LichSuDatVe");
        }
        // 1. TRANG CHỌN SUẤT CHIẾU 
        public ActionResult Index(int? maPhim)
        {
            if (maPhim == null) return RedirectToAction("Index", "Home");

            var phim = db.Phims.Find(maPhim);
            // Lấy suất chiếu của phim này trong tương lai (tính từ hôm nay)
            var suatChieus = db.SuatChieux
                .Where(s => s.MaPhim == maPhim && s.NgayChieu >= DateTime.Today)
                .OrderBy(s => s.NgayChieu).ThenBy(s => s.GioChieu)
                .ToList();

            ViewBag.Phim = phim;
            return View(suatChieus);
        }

        // 2. TRANG CHỌN GHẾ (Action quan trọng nhất)
        
        public ActionResult ChonGhe(int? maSC)
        {
            if (Session["TaiKhoan"] == null)
            {
                return RedirectToAction("DangNhap", "TaiKhoan_65131636");
            }

            if (maSC == null) return RedirectToAction("Index", "Home");

            // Lấy thông tin suất chiếu
            var suatChieu = db.SuatChieux.Find(maSC);
            var phong = db.Phongs.Find(suatChieu.MaPhong);

            // Lấy tất cả ghế trong phòng
            var tatCaGhe = db.Ghes.Where(g => g.MaPhong == phong.MaPhong).ToList();

            // Lấy danh sách ghế đã được đặt cho suất chiếu này
            // Tìm trong bảng Ve -> Join bảng DatVe -> Check MaSC
            var gheDaDat = db.Ves
                .Where(v => v.DatVe.MaSC == maSC)
                .Select(v => v.MaGhe.Value) // Lấy ra ID ghế
                .ToList();

            var model = new DatVeViewModel
            {
                Phim = suatChieu.Phim,
                SuatChieu = suatChieu,
                Phong = phong,
                DanhSachGhe = tatCaGhe,
                DanhSachMaGheDaDat = gheDaDat
            };

            return View(model);
        }

        // ---TRANG CHỌN DỊCH VỤ ---
        [HttpPost] // Nhận dữ liệu từ trang Chọn Ghế
        public ActionResult ChonDichVu(int maSC, string danhSachGheChon)
        {
            if (Session["TaiKhoan"] == null) return RedirectToAction("DangNhap", "TaiKhoan_65131636");

            // Lưu tạm thông tin ghế vào ViewBag để truyền tiếp sang View Dịch vụ
            ViewBag.MaSC = maSC;
            ViewBag.DanhSachGheChon = danhSachGheChon;

            // Tính tạm tiền vé để hiển thị
            var suatChieu = db.SuatChieux.Find(maSC);
            var soLuongGhe = danhSachGheChon.Split(',').Length;
            ViewBag.TongTienVe = soLuongGhe * (suatChieu.GiaVe ?? 0);

            // Lấy danh sách dịch vụ
            var dichVus = db.DichVus.ToList();
            return View(dichVus);
        }

        // --- THANH TOÁN (XỬ LÝ CẢ VÉ + DỊCH VỤ + TRẠNG THÁI) ---
        [HttpPost]
        public ActionResult LuuDonHang(int maSC, string danhSachGheChon, string danhSachDichVu)
        {
        

            if (Session["TaiKhoan"] == null) return RedirectToAction("DangNhap", "TaiKhoan_65131636");

            var maKH = (int)Session["MaKH"];
            var suatChieu = db.SuatChieux.Find(maSC);
            var listMaGhe = danhSachGheChon.Split(',').Select(int.Parse).ToList();

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    // 1. Tạo Đơn đặt vé (Trạng thái 0 = Chờ duyệt)
                    var datVe = new DatVe
                    {
                        MaKH = maKH,
                        MaSC = maSC,
                        NgayDat = DateTime.Now,
                        TrangThai = 0 
                    };
                    db.DatVes.Add(datVe);
                    db.SaveChanges();

                    // 2. Lưu chi tiết Vé (Ghế)
                    foreach (var maGhe in listMaGhe)
                    {
                        var ve = new Ve
                        {
                            MaDatVe = datVe.MaDatVe,
                            MaGhe = maGhe,
                            GiaVe = suatChieu.GiaVe
                        };
                        db.Ves.Add(ve);
                    }

                    // 3. Lưu dịch vụ (Nếu khách có chọn)
                    if (!string.IsNullOrEmpty(danhSachDichVu))
                    {
                        var cacDichVu = danhSachDichVu.Split(','); 
                        foreach (var item in cacDichVu)
                        {
                            var parts = item.Split('-');
                            int maDV = int.Parse(parts[0]);
                            int soLuong = int.Parse(parts[1]);

                            if (soLuong > 0)
                            {
                                var hddv = new HoaDonDichVu
                                {
                                    MaKH = maKH,
                                    MaDV = maDV,
                                    SoLuong = soLuong,
                                    NgayMua = DateTime.Now,
                                    MaDatVe = datVe.MaDatVe
                                };
                                db.HoaDonDichVus.Add(hddv);
                            }
                        }
                    }

                    db.SaveChanges();
                    transaction.Commit();

                    return RedirectToAction("XacNhanDatVe", new { id = datVe.MaDatVe });
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    return View("Error"); // Bạn nên tạo 1 view báo lỗi
                }
            }
        }
        [HttpPost]
        
        public ActionResult XacNhanDonHang(int maSC, string danhSachGheChon, string danhSachDichVu)
        {
            if (Session["TaiKhoan"] == null) return RedirectToAction("DangNhap", "TaiKhoan_65131636");
            // Kiểm tra độ tuổi    
            // --- 1. LẤY THÔNG TIN CẦN THIẾT ---
            int maKH = (int)Session["MaKH"];
            var khachHang = db.KhachHangs.Find(maKH);
            var suatChieu = db.SuatChieux.Find(maSC);
            var phim = suatChieu.Phim;

            // --- 2. TÍNH SỐ LƯỢNG GHẾ  ---
            int soLuongGhe = 0;
            if (!string.IsNullOrEmpty(danhSachGheChon))
            {
                soLuongGhe = danhSachGheChon.Split(',').Length;
            }

            // --- 3. KIỂM TRA ĐỘ TUỔI ---
           
            int doTuoiYeuCau = phim.DoTuoiYeuCau ?? 0;

            if (doTuoiYeuCau > 0)
            {
                // Gọi hàm SQL kiểm tra tuổi
                var checkTuoi = db.Database.SqlQuery<bool>(
                    "SELECT dbo.KiemTraDoTuoi(@p0, @p1)", khachHang.NgaySinh, doTuoiYeuCau
                ).Single();

                // Xử lý khi KHÔNG đủ tuổi
                if (!checkTuoi)
                {
                    ViewBag.Error = $"Phim này yêu cầu khán giả trên {doTuoiYeuCau} tuổi. Bạn chưa đủ tuổi để xem!";

              
                    ViewBag.MaSC = maSC;
                    ViewBag.DanhSachGheChon = danhSachGheChon;
                 
                    ViewBag.TongTienVe = soLuongGhe * (suatChieu.GiaVe ?? 0);
                    return View("ChonDichVu", db.DichVus.ToList());
                }
            }

            // TÍNH TỔNG TIỀN

            // 1. Tính lại tiền vé
            suatChieu = db.SuatChieux.Find(maSC);

            // Xử lý đếm số lượng ghế 
            soLuongGhe = 0;
            if (!string.IsNullOrEmpty(danhSachGheChon))
            {
                soLuongGhe = danhSachGheChon.Split(',').Length;
            }

            decimal tienVe = (decimal)(soLuongGhe * (suatChieu.GiaVe ?? 0));

            // 2. Tính tiền dịch vụ 
            decimal tienDichVu = 0;
            var listTenDichVu = new List<string>();

            if (!string.IsNullOrEmpty(danhSachDichVu))
            {
                var cacDichVu = danhSachDichVu.Split(',');
                foreach (var item in cacDichVu)
                {
                    var parts = item.Split('-'); 
                    int maDV = int.Parse(parts[0]);
                    int sl = int.Parse(parts[1]);

                    var dv = db.DichVus.Find(maDV);

                 
                    if (dv != null && sl > 0)
                    {
                        decimal thanhTienItem = (decimal)(sl * dv.Gia);

                        // Cộng vào tổng tiền dịch vụ
                        tienDichVu += thanhTienItem;

                        // Tạo chuỗi hiển thị: "Tên (xSL) - Thành tiền"
                       
                        listTenDichVu.Add($"{dv.TenDV} (x{sl}) - {string.Format("{0:N0}", thanhTienItem)} đ");
                    }
                }
            }
            // 3. GỌI HÀM SQL TÍNH GIẢM GIÁ
            
            decimal tiLeGiam = db.Database.SqlQuery<decimal>(
                "SELECT dbo.TinhGiamGia(@p0)", khachHang.NgaySinh
            ).SingleOrDefault();

            decimal soTienGiam = tienVe * tiLeGiam;
            decimal tongTienVeSauGiam = tienVe - soTienGiam;
            // 4. Tính tổng thanh toán cuối cùng
            decimal tongCong = tongTienVeSauGiam + tienDichVu;

            // 5. Đẩy dữ liệu sang View
            ViewBag.MaSC = maSC;
            ViewBag.DanhSachGheChon = danhSachGheChon;
            ViewBag.DanhSachDichVu = danhSachDichVu;

            ViewBag.TenPhim = suatChieu.Phim.TenPhim;
            ViewBag.Phong = suatChieu.Phong.TenPhong;
            ViewBag.GioChieu = $"{suatChieu.GioChieu} - {suatChieu.NgayChieu:dd/MM/yyyy}";

            ViewBag.SoLuongGhe = soLuongGhe;
            ViewBag.TienVe = tienVe;
            ViewBag.TienDichVu = tienDichVu;
            ViewBag.TongTien = tienVe + tienDichVu;
            // --- Dữ liệu giảm giá ---
            ViewBag.TiLeGiam = tiLeGiam * 100; 
            ViewBag.SoTienGiam = soTienGiam;   
            ViewBag.TongCong = tongCong;      
            ViewBag.ChiTietDichVu = listTenDichVu;

            return View(); 
        }

   
        public ActionResult XacNhanDatVe(int id)
        {

            // 1. Lấy dữ liệu đơn hàng
            var datVe = db.DatVes.Include("Ves")
                                 .Include("KhachHang") 
                                 .Include("HoaDonDichVus")
                                 .Include("HoaDonDichVus.DichVu")
                                 .Include("SuatChieu.Phim")
                                 .Include("SuatChieu.Phong")
                                 .FirstOrDefault(d => d.MaDatVe == id);

            if (datVe == null) return HttpNotFound();

            // 2. TÍNH TOÁN GIẢM GIÁ (Logic backend)
            decimal tongTienVe = datVe.Ves.Sum(v => v.GiaVe ?? 0);

            // Gọi hàm SQL tính giảm giá dựa trên ngày sinh khách hàng trong đơn
            decimal tiLeGiam = 0;
            if (datVe.KhachHang != null && datVe.KhachHang.NgaySinh.HasValue)
            {
                tiLeGiam = db.Database.SqlQuery<decimal>(
                    "SELECT dbo.TinhGiamGia(@p0)", datVe.KhachHang.NgaySinh
                ).SingleOrDefault();
            }

            decimal soTienGiam = tongTienVe * tiLeGiam;
            decimal tongTienVeSauGiam = tongTienVe - soTienGiam;

            // 3. Tính tiền dịch vụ
            decimal tongTienDV = 0;
            if (datVe.HoaDonDichVus != null)
            {
                tongTienDV = datVe.HoaDonDichVus.Sum(hd => (hd.SoLuong ?? 0) * (hd.DichVu.Gia ?? 0));
            }

            decimal tongCong = tongTienVeSauGiam + tongTienDV;

            // 4. Truyền các giá trị đã tính sang View qua ViewBag
            ViewBag.TiLeGiam = tiLeGiam;     
            ViewBag.SoTienGiam = soTienGiam; 
            ViewBag.TongCong = tongCong;    

            return View(datVe);
        }
    }
}