﻿using System;
using System.Collections.Generic;

namespace QLRP_CGV_65131636.Models 
{
    public class ThongKeViewModel
    {
        // 1. Các số liệu tổng quan
        public decimal TongDoanhThu { get; set; }
        public int TongSoVeBanRa { get; set; }
        public decimal DoanhThuDichVu { get; set; } // Bắp nước
        public int SoLuongPhimDangChieu { get; set; }

        // 2. Danh sách top phim (để vẽ biểu đồ hoặc hiện bảng)
        public List<TopPhimViewModel> TopPhims { get; set; }
        public DateTime? TuNgay { get; set; }
        public DateTime? DenNgay { get; set; }
    }

    // Class con để chứa thông tin từng phim trong top
    public class TopPhimViewModel
    {
        public string TenPhim { get; set; }
        public int SoVeDaBan { get; set; }
        public decimal DoanhThuPhim { get; set; }
    }
}