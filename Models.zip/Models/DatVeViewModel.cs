﻿using System;
using System.Collections.Generic;

namespace _65131636_QLRP.Models
{
    public class DatVeViewModel
    {
        public Phim Phim { get; set; }
        public SuatChieu SuatChieu { get; set; }
        public Phong Phong { get; set; }
        public List<Ghe> DanhSachGhe { get; set; }
        public List<int> DanhSachMaGheDaDat { get; set; } // Danh sách ID các ghế đã có người mua
    }
}