﻿using System;
using System.Collections.Generic;

namespace _65131636_QLRP.Models
{
    // Class chứa thông tin chi tiết vé
    public class ChiTietVe
    {
        public string TenGhe { get; set; }
        public decimal GiaVe { get; set; }
    }

    // Class chứa thông tin dịch vụ
    public class ChiTietDichVu
    {
        public string TenDV { get; set; }
        public int SoLuong { get; set; }
        public decimal Gia { get; set; }
        public decimal ThanhTien { get; set; }
    }

    // Class chính hiển thị hóa đơn
    public class HoaDonViewModel
    {
        // Thông tin chung
        public int MaDatVe { get; set; }
        public string HoTenKH { get; set; }
        public string SDT { get; set; }
        public string TenPhim { get; set; }
        public string TenPhong { get; set; }
        public DateTime? NgayDat { get; set; }
        public DateTime? NgayChieu { get; set; }
        public TimeSpan? GioChieu { get; set; }

        // Danh sách chi tiết
        public List<ChiTietVe> DanhSachVe { get; set; }
        public List<ChiTietDichVu> DanhSachDichVu { get; set; }

        // Tổng tiền
        public decimal TongTien { get; set; }
    }
}