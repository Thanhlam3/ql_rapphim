﻿using _65131636_QLRP.Models;
using System.Collections.Generic;


namespace _65131636_QLRP.Models
{
    public class TimKiemViewModel
    {
        // 1. Dữ liệu đầu vào (Người dùng nhập/chọn)
        public string TuKhoa { get; set; }
        public int[] MaTLs { get; set; } // Danh sách ID thể loại được chọn

        // 2. Dữ liệu để hiển thị lên View
        public List<TheLoai> TatCaTheLoai { get; set; } // Để render ra các checkbox
        public List<Phim> KetQuaTimKiem { get; set; } // Danh sách phim tìm thấy
    }
}