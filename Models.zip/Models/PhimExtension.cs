﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace _65131636_QLRP.Models
{
    // Dùng "partial" để nối thêm vào class Phim gốc
    public partial class Phim
    {
        
        // Thuộc tính này không lưu trong Database, chỉ để hiện lên web
        [NotMapped]
        public string TenTheLoai { get; set; }
    }
}