﻿using System;
using System.Collections.Generic;

namespace _65131636_QLRP.Models
{
    // Dùng để chứa toàn bộ dữ liệu trang Lịch Chiếu
    public class LichChieuViewModel
    {
        public DateTime NgayHienTai { get; set; }
        public List<DateTime> DanhSachNgay { get; set; }
        public List<PhimLichChieuItem> DanhSachPhim { get; set; }
    }

    // Dùng để chứa thông tin từng phim và các suất chiếu của nó
    public class PhimLichChieuItem
    {
        public Phim Phim { get; set; }
        public List<SuatChieuInfo> SuatChieus { get; set; }
    }

    // Dùng để chứa thông tin từng ô giờ chiếu (Giờ + Ghế trống)
    public class SuatChieuInfo
    {
        public int MaSC { get; set; }
        public TimeSpan GioChieu { get; set; }
        public int GheTrong { get; set; }
    }
}